from delta import *
from pyspark.sql.functions import count
import pyspark


builder = pyspark.sql.SparkSession.builder.appName("spark_delta_lake") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")

spark = configure_spark_with_delta_pip(builder).getOrCreate()

# Load data from csv file
flights = spark.read.format("csv") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .load("us_flight/2008.csv")

# Query from csv file
flights.filter("DayOfWeek = 1") \
        .groupBy("Month", "Origin") \
        .agg(count("*").alias("TotalFlights")) \
        .orderBy("TotalFlights", ascending=False) \
        .limit(20).count()

# Write Parquet-based table from flights data
flights.write.format("parquet") \
  .mode("overwrite") \
  .partitionBy("DayOfWeek") \
  .save("flights_parquet")
  
# Read Parquet-based table
flights_parquet = spark.read.format("parquet") \
	.load("flights_parquet")

# Query with Parquet-based table
flights_parquet.filter("DayOfWeek = 1") \
        .groupBy("Month", "Origin") \
        .agg(count("*").alias("TotalFlights")) \
        .orderBy("TotalFlights", ascending=False) \
        .limit(20).count()
        
# Write Delta table from flights data
flights.write.format("delta") \
  .mode("overwrite") \
  .partitionBy("DayOfWeek") \
  .save("flights_delta")
  
# Read Delta table
flights_delta = spark.read.format("delta") \
	.load("flights_delta")

# Query with Delta table
flights_delta.filter("DayOfWeek = 1") \
        .groupBy("Month", "Origin") \
        .agg(count("*").alias("TotalFlights")) \
        .orderBy("TotalFlights", ascending=False) \
        .limit(20).count()
